/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : traffic.c
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Declaration of functions for traffic light control.
 *
 * $Id: traffic.h 14 2011-07-02 19:42:04Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#ifndef __TRAFFIC_H
#define __TRAFFIC_H

#include <stdbool.h>
#include <stdint.h>

void traffic_init();
void traffic_enable();
void traffic_disable();
bool traffic_isdisabled();
void traffic_hack();
bool traffic_setspeed(uint8_t speed);
void traffic_setstopped_cb(void (*cb)());
void traffic_setstarted_cb(void (*cb)());

#endif
