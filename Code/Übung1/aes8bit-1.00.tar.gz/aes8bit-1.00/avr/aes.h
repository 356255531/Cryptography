/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : aes.h
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Declaration of public AES functions.
 *
 * $Id: aes.h 9 2011-06-28 14:53:01Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#ifndef __AES_H
#define __AES_H

#include <stdint.h>

void aes_init();
void aes_encipherState(uint8_t *state);
void aes_decipherState(uint8_t *state);

#endif
