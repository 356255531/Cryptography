/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : usart.h
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Declaration of functions for USART communication.
 *
 * $Id: usart.h 4 2011-06-27 11:47:08Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#ifndef __USART_H
#define __USART_H

void usart_init(unsigned long baud_rate);
void usart_puts(const char *str);
char usart_getc();
int usart_ready();

#endif // __USART_H
