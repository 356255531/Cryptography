/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : usart.c
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Definition of functions for USART communication.
 *
 * $Id: usart.c 9 2011-06-28 14:53:01Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#include <avr/interrupt.h>
#include "usart.h"

// Buffer definition
#define RBUFFLEN 40
volatile unsigned char rbuff[RBUFFLEN];
volatile uint8_t rbuffpos,
rbuffcnt,
udr_data;

void usart_init(unsigned long baud_rate)
{
    register uint16_t rate = F_CPU / (baud_rate * 16L) - 1;

    rbuffcnt = 0;

    sei();

#if defined(__AVR_ATmega644__ ) || defined(__AVR_ATmega644P__ )|| defined(__AVR_ATmega1284P__) || defined(__AVR_ATmega88__)
    UCSR0B |= (1 << TXEN0);
    UCSR0B |= (1 << RXEN0);
    UCSR0B |= (1 << RXCIE0);
    UCSR0C |= (1 << UCSZ00) | (1 << UCSZ01);
    UBRR0H = (uint8_t) (rate >> 8);
    UBRR0L = (uint8_t) rate;
#else
    UCSRB |= (1 << TXEN);
    UCSRB |= (1 << RXEN);
    UCSRB |= (1 << RXCIE);
    UCSRC |= (1 << URSEL) | (1 << UCSZ0) | (1 << UCSZ1);
    UBRRH = (uint8_t) (rate >> 8);
    UBRRL = (uint8_t) rate;
#endif
}

void usart_puts(const char *str)
{
#if defined(__AVR_ATmega644__ ) || defined(__AVR_ATmega644P__ )|| defined(__AVR_ATmega1284P__) || defined(__AVR_ATmega88__)
    while(*str) {
        while(!(UCSR0A & (1 << UDRE0)))
            ;
        UDR0 = *str;
        str++;
    }
#else
    while(*str) {
        while(!(UCSRA & (1 << UDRE)))
            ;
        UDR = *str;
        str++;
    }
#endif
}

#if defined(__AVR_ATmega644__ ) || defined(__AVR_ATmega644P__ )|| defined(__AVR_ATmega1284P__)
ISR(USART0_RX_vect)
#elif defined(__AVR_ATmega88__)
ISR(USART_RX_vect)
#else

ISR(USART_RXC_vect)
#endif
{
#if defined(__AVR_ATmega644__ ) || defined(__AVR_ATmega644P__ )|| defined(__AVR_ATmega1284P__) || defined(__AVR_ATmega88__)
    udr_data = UDR0;
#else
    udr_data = UDR;
#endif
    if(rbuffcnt < RBUFFLEN)
        rbuff[(rbuffpos + rbuffcnt++) % RBUFFLEN] = udr_data;
}

int usart_ready()
{
    return rbuffcnt;
}

char usart_getc()
{
    char c;

    while(!rbuffcnt)
        ;

    cli();

    rbuffcnt--;
    c = rbuff [rbuffpos++];
    if(rbuffpos >= RBUFFLEN)
        rbuffpos = 0;

    sei();

    return c;
}
