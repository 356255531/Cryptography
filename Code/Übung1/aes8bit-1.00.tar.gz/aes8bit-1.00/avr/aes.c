/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : aes.c
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Implementation of AES.
 *
 * $Id: aes.c 16 2012-02-13 18:35:26Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#include <avr/eeprom.h>
#include "aes.h"

// AES key and number of rounds in EEPROM
extern uint8_t ee_key[32] EEMEM;
extern uint8_t ee_rnum EEMEM;

// expanded AES key and number of rounds in RAM
volatile uint8_t key[240];
volatile uint8_t rnum;

/*
 * Methods implementing operations in GF(256)
 */

/*
 * Multiplication in GF(256)
 * r = p * q
 */
uint8_t gmul(uint8_t p, uint8_t q)
{
    uint8_t r = 0;
    for(uint8_t i = 0; i < 8; i++) {
        if(q & 0x01)
            r ^= p;
        if(p & 0x80) {
            p <<= 1;
            p ^= 0x1b;
        } else
            p <<= 1;
        q >>= 1;
    }
    return r;
}

/*
 * Degree of polynom in GF(256)
 */
uint8_t gdeg(uint8_t x)
{
    x |= x >> 1;
    x |= x >> 2;
    x |= x >> 4;
    return (x + 1) >> 2;
}

/*
 * Calculation of multiplicative inverse in GF(256)
 */
uint8_t gmulinv(uint8_t u)
{
    if(u < 2)
        return u;

    uint8_t v = 0x1b, zj1 = gdeg(u), zj2 = 0x80, g1 = 1, g2 = 0;

    while(u != 1 && v != 1) {
        if(zj2 >= zj1) {
            zj2 /= zj1;
            v ^= u * zj2;
            g2 ^= g1 * zj2;
            zj2 = gdeg(v);
        } else {
            zj1 /= zj2;
            u ^= v * zj1;
            g1 ^= g2 * zj1;
            zj1 = gdeg(u);
        }
    }

    return (u == 1 ? g1 : g2);
}

/*
 * Functions implementing encryption
 */

inline uint8_t subByte(uint8_t x)
{
    x = gmulinv(x);
    return 0x63 ^ x ^ (x << 1) ^ (x << 2) ^ (x << 3) ^ (x << 4)
            ^ (x >> 7) ^ (x >> 6) ^ (x >> 5) ^ (x >> 4);
}

void subBytes(uint8_t *state)
{
    for(uint8_t n = 0; n < 16; n++) {
        state[n] = subByte(state[n]);
    }
}

void shiftRows(uint8_t *state)
{
    uint8_t tmp;
    // row 1
    // nothing to do here
    // row 2
    tmp = state[1];
    state[1] = state[5];
    state[5] = state[9];
    state[9] = state[13];
    state[13] = tmp;
    // row 3
    tmp = state[2];
    state[2] = state[10];
    state[10] = tmp;
    tmp = state[6];
    state[6] = state[14];
    state[14] = tmp;
    // row 4
    tmp = state[3];
    state[3] = state[15];
    state[15] = state[11];
    state[11] = state[7];
    state[7] = tmp;
}

void mixColumn(uint8_t *column)
{
    uint8_t tmp[4];

    tmp[0] = column[0];
    tmp[1] = column[1];
    tmp[2] = column[2];
    tmp[3] = column[3];

    column[0] = gmul(tmp[0], 2) ^ gmul(tmp[1], 3) ^ tmp[2] ^ tmp[3];
    column[1] = tmp[0] ^ gmul(tmp[1], 2) ^ gmul(tmp[2], 3) ^ tmp[3];
    column[2] = tmp[0] ^ tmp[1] ^ gmul(tmp[2], 2) ^ gmul(tmp[3], 3);
    column[3] = gmul(tmp[0], 3) ^ tmp[1] ^ tmp[2] ^ gmul(tmp[3], 2);
}

void mixColumns(uint8_t *state)
{
    for(uint8_t n = 0; n < 16; n += 4)
        mixColumn(&state[n]);
}

/*
 * Functions implementing decryption
 */

inline uint8_t invSubByte(uint8_t x)
{
    x = 0x05 ^ (x << 1) ^ (x << 3) ^ (x << 6) ^ (x >> 7) ^ (x >> 5) ^ (x >> 2);
    return gmulinv(x);
}

void invSubBytes(uint8_t *state)
{
    for(uint8_t n = 0; n < 16; n++) {
        state[n] = invSubByte(state[n]);
    }
}

void invShiftRows(uint8_t *state)
{
    uint8_t tmp;
    // row 1
    // nothing to do here
    // row 2
    tmp = state[1];
    state[1] = state[13];
    state[13] = state[9];
    state[9] = state[5];
    state[5] = tmp;
    // row 3
    tmp = state[2];
    state[2] = state[10];
    state[10] = tmp;
    tmp = state[6];
    state[6] = state[14];
    state[14] = tmp;
    // row 4
    tmp = state[3];
    state[3] = state[7];
    state[7] = state[11];
    state[11] = state[15];
    state[15] = tmp;
}

void invMixColumn(uint8_t *column)
{
    uint8_t tmp[4];

    tmp[0] = column[0];
    tmp[1] = column[1];
    tmp[2] = column[2];
    tmp[3] = column[3];

    column[0] = gmul(tmp[0], 0x0e) ^ gmul(tmp[1], 0x0b)
            ^ gmul(tmp[2], 0x0d) ^ gmul(tmp[3], 0x09);
    column[1] = gmul(tmp[0], 0x09) ^ gmul(tmp[1], 0x0e)
            ^ gmul(tmp[2], 0x0b) ^ gmul(tmp[3], 0x0d);
    column[2] = gmul(tmp[0], 0x0d) ^ gmul(tmp[1], 0x09)
            ^ gmul(tmp[2], 0x0e) ^ gmul(tmp[3], 0x0b);
    column[3] = gmul(tmp[0], 0x0b) ^ gmul(tmp[1], 0x0d)
            ^ gmul(tmp[2], 0x09) ^ gmul(tmp[3], 0x0e);
}

void invMixColumns(uint8_t *state)
{
    for(uint8_t n = 0; n < 16; n += 4)
        invMixColumn(&state[n]);
}

/*
 * Functions for both modes
 */

void addRoundKey(uint8_t *state, uint8_t round)
{
    uint8_t n, m;
    for(n = 0, m = round * 16; n < 16; n++, m++)
        state[n] ^= key[m];
}

/*
 * Key Expansion
 */

void expandKey()
{
    static uint8_t rcon[15] = {
        0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40,
        0x80, 0x1b, 0x36, 0x6c, 0xd8, 0xab, 0x4d, 0x9a
    };
    uint8_t i, tmp[4];

    // read number of round from EEPROM
    eeprom_busy_wait();
    rnum = eeprom_read_byte(&ee_rnum);
    // calculate number of key words
    uint8_t knum = (rnum == 10 ? 4 : (rnum == 12 ? 6 : 8));

    // read AES key from EEPROM and put it into
    // the lower bytes of round key array
    eeprom_busy_wait();
    eeprom_read_block(key, ee_key, knum * 4);

    // calculate the other round keys
    for(i = knum * 4; i < 16 * (rnum + 1); i += 4) {
        tmp[0] = key[i - 4];
        tmp[1] = key[i - 3];
        tmp[2] = key[i - 2];
        tmp[3] = key[i - 1];

        if((i / 4) % knum == 0) {
            uint8_t trans = tmp[0];
            tmp[0] = tmp[1];
            tmp[1] = tmp[2];
            tmp[2] = tmp[3];
            tmp[3] = trans;

            tmp[0] = subByte(tmp[0]);
            tmp[1] = subByte(tmp[1]);
            tmp[2] = subByte(tmp[2]);
            tmp[3] = subByte(tmp[3]);

            tmp[0] = tmp[0] ^ rcon[i / (knum * 4) - 1];
            tmp[1] = tmp[1] ^ 0x00;
            tmp[2] = tmp[2] ^ 0x00;
            tmp[3] = tmp[3] ^ 0x00;
        } else if(knum > 6 && (i / 4) % knum == 4) {
            tmp[0] = subByte(tmp[0]);
            tmp[1] = subByte(tmp[1]);
            tmp[2] = subByte(tmp[2]);
            tmp[3] = subByte(tmp[3]);
        }

        key[i] = key[i - knum * 4] ^ tmp[0];
        key[i + 1] = key[i - knum * 4 + 1] ^ tmp[1];
        key[i + 2] = key[i - knum * 4 + 2] ^ tmp[2];
        key[i + 3] = key[i - knum * 4 + 3] ^ tmp[3];
    }
}

void aes_encipherState(uint8_t *state)
{
    addRoundKey(state, 0);
    for(int r = 1; r < rnum; r++) {
        subBytes(state);
        shiftRows(state);
        mixColumns(state);
        addRoundKey(state, r);

    }
    subBytes(state);
    shiftRows(state);
    addRoundKey(state, rnum);
}

void aes_decipherState(uint8_t *state)
{
    addRoundKey(state, rnum);
    for(int r = rnum - 1; r > 0; r--) {
        invShiftRows(state);
        invSubBytes(state);
        addRoundKey(state, r);
        invMixColumns(state);
    }
    invShiftRows(state);
    invSubBytes(state);
    addRoundKey(state, 0);
}

void aes_init()
{
    expandKey();
}
