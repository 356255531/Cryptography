/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : traffic.c
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Definition of traffic light control via timer.
 *
 * $Id: traffic.c 16 2012-02-13 18:35:26Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#include "traffic.h"
#include <stdlib.h>
#include <avr/io.h>
#include <avr/interrupt.h>

static const uint8_t control[10] = {
    0b00100100,
    0b00100010,
    0b01100001,
    0b10000001,
    0b01000001,
    0b00100011,
    0b00100001, // both red light
    0b00100001, // both red light (again for smooth startup)
    0b00100011, // smooth startup
    0b10000100 // "Die Hard 4" state -- both green light
};
volatile uint8_t state;
volatile bool disable;
volatile bool stopped;

volatile void (*cb_stopped)() = NULL;
volatile void (*cb_started)() = NULL;

ISR(TIMER1_OVF_vect)
{
    state++;
    if(!disable && (state == 6 || state == 9))
        state = 0;
    else if(disable && state == 5)
        state = 6;
    PORTA = control[state];
    if(disable && state == 6) {
        stopped = true;
        TIMSK &= ~(1 << TOIE1);
        if(cb_stopped != NULL)
            cb_stopped();
    }
}

void traffic_enable()
{
    disable = false;
    state = 6;
    PORTA = control[state];
    stopped = false;
    TIMSK |= (1 << TOIE1);
    if(cb_started != NULL)
        cb_started();
}

void traffic_disable()
{
    disable = true;
}

bool traffic_isdisabled()
{
    return disable;
}

void traffic_hack()
{
    stopped = true;
    TIMSK &= ~(1 << TOIE1);
    PORTA = control[9];
    disable = true;
}

bool traffic_setspeed(uint8_t speed)
{
    bool ret = true;
    if(!stopped)
        TIMSK &= ~(1 << TOIE1);
    switch(speed) {
        case '1': // Prescaler /8
            TCCR1B &= ~((1 << CS12) | (1 << CS10));
            TCCR1B |= (1 << CS11);
            break;
        case '2': // Prescaler /64
            TCCR1B &= ~(1 << CS12);
            TCCR1B |= (1 << CS11) | (1 << CS10);
            break;
        case '3': // Prescaler /256
            TCCR1B &= ~((1 << CS11) | (1 << CS10));
            TCCR1B |= (1 << CS12);
            break;
        case '4': // Prescaler /1024
            TCCR1B &= ~(1 << CS11);
            TCCR1B |= (1 << CS12) | (1 << CS10);
            break;
        default:
            ret = false;
    }
    if(!stopped)
        TIMSK |= (1 << TOIE1);
    return ret;
}

void traffic_init()
{
    DDRA = 0xFF;
    sei();
    TCCR1A = 0;
    TCCR1B |= (1 << ICNC1) | (1 << ICES1);
    traffic_setspeed('3');
    traffic_enable();
}

void traffic_setstopped_cb(void (*cb)())
{
    cb_stopped = cb;
}

void traffic_setstarted_cb(void (*cb)())
{
    cb_started = cb;
}
