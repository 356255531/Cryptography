/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : aes8bit.c
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Main program.
 *
 * $Id: aes8bit.c 15 2011-07-02 20:23:20Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#include "usart.h"
#include "traffic.h"
#include "aes.h"
#include "version.h"

void started_cb()
{
    usart_puts("IStarted\n\r");
}

void stopped_cb()
{
    usart_puts("IStopped\n\r");
}

void testAES()
{
    usart_puts("IRunning AES Test\n\r");
    uint8_t state[16], j;
    for(j = 0; j < 16; j++)
        state[j] = j;
    aes_encipherState(state);
    aes_decipherState(state);
    uint8_t ok = 1;
    for(j = 0; j < 16; j++)
        if(state[j] != j) {
            ok = 0;
            break;
        }
    if(ok == 1) {
        usart_puts("ITest OK\n\r");
    } else {
        usart_puts("ETest FAILED\n\r");
    }
}

void encryptedCommand()
{
    uint8_t i, c, state[16];

    // convert hex string to state array
    usart_puts("IConverting...\n\r");
    for(i = 0; i < 16; i++) {
        c = usart_getc();
        if(c >= '0' && c <= '9')
            state[i] = (c - '0') << 4;
        else if(c >= 'A' && c <= 'F')
            state[i] = (c - 'A' + 10) << 4;
        else if(c >= 'a' && c <= 'f')
            state[i] = (c - 'a' + 10) << 4;
        else {
            c = 0xFF;
            break;
        }
        c = usart_getc();
        if(c >= '0' && c <= '9')
            state[i] += c - '0';
        else if(c >= 'A' && c <= 'F')
            state[i] += c - 'A' + 10;
        else if(c >= 'a' && c <= 'f')
            state[i] += c - 'a' + 10;
        else {
            c = 0xFF;
            break;
        }
    }
    if(c == 0xFF) {
        usart_puts("ESyntax error\n\r");
        return;
    }

    // decipher state and verify it
    usart_puts("IDecrypting...\n\r");
    aes_decipherState(state);
    for(c = 0, i = 0; i < 15; i++)
        c ^= state[i];
    if(state[15] != c) {
        usart_puts("EDecryption failed\n\r");
        return;
    }

    // execute command
    usart_puts("IRequest accepted\n\r");
    switch(state[0]) {
        case '0': // Stop
            if(traffic_isdisabled()) {
                usart_puts("IAlready stopped\n\r");
            } else {
                usart_puts("IStopping...\n\r");
                traffic_disable();
            }
            break;
        case '1': // Start
            if(traffic_isdisabled()) {
                usart_puts("IStarting...\n\r");
                traffic_enable();
            } else {
                usart_puts("IAlready started\n\r");
            }
            break;
        case 'h': // Die Hard 4 State
            traffic_hack();
            usart_puts("IHacked\n\r");
            break;
        case 's': // Change speed of traffic light switching
            if(traffic_setspeed(state[1]))
                usart_puts("IChanged speed\n\r");
            else
                usart_puts("EError chaning speed\n\r");
            break;
        default: // Unknown Command
            usart_puts("EUnknown command\n\r");
    }
}

void welcome()
{
    usart_puts("Iaes8bit ");
    usart_puts(getversion());
    usart_puts("\n\r"
            "ICopyright (c) 2011 Oliver Mueller, "
            "http://www.cogito-ergo-sum.org/\n\r"
            "IAll rights reserved.\n\r");
}

int main()
{
    traffic_init();
    usart_init(38400L);

    welcome();
    traffic_setstopped_cb(stopped_cb);
    traffic_setstarted_cb(started_cb);

    usart_puts("ILoading AES key\n\r");
    aes_init();

    char c[2];
    c[1] = '\0';
    while(1) {
        c[0] = usart_getc();
        switch(c[0]) {
            case 'v': // Version information
                welcome();
                break;
            case 'e': // Echo
                c[0] = 'I';
                usart_puts(c);
                while(c[0] != '\n') {
                    c[0] = usart_getc();
                    usart_puts(c);
                }
                break;
            case 'T': // Test
                testAES();
                break;
            case '#':
                encryptedCommand();
                break;
        }
    }
}
