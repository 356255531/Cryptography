/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : eeprom.c
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Definition of key in EEPROM.
 *
 * $Id: eeprom.c 9 2011-06-28 14:53:01Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#include <avr/eeprom.h>

uint8_t ee_rnum EEMEM = 14;
uint8_t ee_key[32] EEMEM = {
    0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07,
    0x08, 0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F,
    0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17,
    0x18, 0x19, 0x1A, 0x1B, 0x1C, 0x1D, 0x1E, 0x1F
};
