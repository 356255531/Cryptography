/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : main.cpp
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Main program of terminal.
 *
 * $Id: main.cpp 15 2011-07-02 20:23:20Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#include <iostream>
#include <iomanip>
#include <vector>
#include <map>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <sys/select.h>
#include <sys/time.h>
#include <fcntl.h>
#include <termios.h>
#include "aes.h"
#include "StateGenerator.h"
#include "version.h"

using namespace std;

int open_serial_port(const char *port)
{
    int fd;
    struct termios options;

    fd = open(port, O_RDWR | O_NOCTTY | O_NDELAY);
    if(fd == -1)
        perror("Unable to open serial port");
    else {
        fcntl(fd, F_SETFL, 0);
        tcgetattr(fd, &options);

        // Set port parameters: 38400 baud 8n1
        cfsetispeed(&options, B38400);
        cfsetospeed(&options, B38400);

        options.c_cflag &= ~PARENB;
        options.c_cflag &= ~CSTOPB;
        options.c_cflag &= ~CSIZE;
        options.c_cflag |= CS8;

        options.c_cflag |= (CLOCAL | CREAD);
        options.c_lflag &= ~(ICANON | ECHO | ISIG);
        options.c_oflag &= ~OPOST;
        options.c_iflag &= ~INLCR;
        options.c_iflag &= ~ICRNL;

        options.c_cc[VMIN] = 1;
        options.c_cc[VTIME] = 0;

        tcsetattr(fd, TCSANOW, &options);
    }
    return fd;
}

#define BUFSIZE  1024

int main(int argc, char** argv)
{
    cout << "aes8term " << Version::getInstance().getVersion() << endl <<
            "Copyright (c) 2011 Oliver Mueller, "
            "http://www.cogito-ergo-sum.org" << endl <<
            "All rights reserved." << endl << endl;

    if(argc != 3) {
        cout << "Usage: aes8term [serial-port key-as-hex]" << endl;
        return 0;
    }

    try {
        // AES object
        AesEncryption aes(argv[2]);

        // StateGenerator object
        StateGenerator sg;

        // command maps
        map<string, string> enccmd;
        enccmd["stop"] = "0";
        enccmd["start"] = "1";
        enccmd["hack"] = "h";
        enccmd["speed 1"] = "s1";
        enccmd["speed 2"] = "s2";
        enccmd["speed 3"] = "s3";
        enccmd["speed 4"] = "s4";
        map<string, string> plaincmd;
        plaincmd["test"] = "T";
        plaincmd["version"] = "v";
        // Greetings as echo command: echo <ISO 639-2/B>
        plaincmd["echo ger"] = "eGuten Tag AVR\n\r"; // German
        plaincmd["echo jpn"] = "eKonichiwa AVR\n\r"; // Japanese
        plaincmd["echo fre"] = "eBonjour AVR\n\r"; // French
        plaincmd["echo eng"] = "eGood afternoon AVR\n\r"; // English
        plaincmd["echo heb"] = "eShalom AVR\n\r"; // Hebrew
        plaincmd["echo ara"] = "eAs-salamu alaikum AVR\n\r"; // Arabic

        map<string, string>::iterator cmd;

        // state object
        string state;

        // file descriptor and select() handling
        fd_set rfds, wfds;
        int sfd = open_serial_port(argv[1]), maxfd = sfd + 1;
        if(sfd == -1)
            return 1;

        // read buffer
        char rbuf[BUFSIZE + 1], num;
        string rstr;
        vector<string> iqueue;

        // write buffer
        const char *wbuf = NULL;
        unsigned woff = 0, wlen;
        vector<string> oqueue;

        // timeout definition
        struct timeval timeout;
        timeout.tv_sec = 10;
        timeout.tv_usec = 0;

        while(1) {
            FD_ZERO(&rfds);
            FD_ZERO(&wfds);
            FD_SET(sfd, &rfds);
            FD_SET(fileno(stdin), &rfds);
            if(!oqueue.empty())
                FD_SET(sfd, &wfds);

            if(select(maxfd, &rfds, &wfds, (fd_set*) 0, &timeout) == 0)
                continue;

            if(FD_ISSET(sfd, &rfds)) {
                num = read(sfd, rbuf, BUFSIZE);
                if(num > 0) {
                    rbuf[num] = '\0';
                    for(int i = 0; i < num; i++) {
                        if(rbuf[i] == '\n') {
                            iqueue.push_back(rstr);
                            rstr = "";
                        } else if(rbuf[i] != '\r') {
                            rstr += rbuf[i];
                        }
                    }
                } else
                    perror("unable to read from serial port");
            }

            if(!iqueue.empty()) {
                vector<string>::iterator iq(iqueue.begin());
                string tmp;
                for(; iq != iqueue.end(); iq++) {
                    tmp = *iq;
                    switch(tmp[0]) {
                        case 'I':
                            cout << "[Info ] ";
                            break;
                        case 'E':
                            cout << "[Error] ";
                            break;
                        default:
                            cout << "[?????] ";
                    }
                    tmp.erase(0, 1);
                    cout << tmp << endl;
                }
                iqueue.clear();
            }

            if(!oqueue.empty() && FD_ISSET(sfd, &wfds)) {
                if(wbuf == NULL) {
                    wbuf = oqueue[0].c_str();
                    wlen = strlen(wbuf);
                    woff = 0;
                }
                int x = write(sfd, &wbuf[woff], wlen);
                if(x == -1) {
                    perror("unable to write to serial port");
                } else {
                    wlen -= x;
                    if(wlen <= 0) {
                        oqueue.erase(oqueue.begin());
                        wlen = 0;
                        wbuf = NULL;
                    } else
                        woff += x;
                }
            }

            if(FD_ISSET(fileno(stdin), &rfds)) {
                fgets(rbuf, BUFSIZE, stdin);
                for(int i = strlen(rbuf) - 1; i >= 0; i--)
                    if(rbuf[i] == '\n' || rbuf[i] == '\r')
                        rbuf[i] = '\0';
                cmd = enccmd.find(rbuf);
                if(cmd != enccmd.end()) {
                    state = sg.getState(cmd->second.c_str());
                    state = aes.encipherToHexString(state);
                    oqueue.push_back("#" + state + "\n\r");
                } else {
                    cmd = plaincmd.find(rbuf);
                    if(cmd != plaincmd.end()) {
                        oqueue.push_back(cmd->second);
                    } else if(rbuf[0] == 'h' || rbuf[0] == '?') { // help
                        cout << "Commands (sent to AVR encrypted):" << endl;
                        for(cmd = enccmd.begin(); cmd != enccmd.end(); cmd++)
                            cout << "  " << cmd->first << endl;
                        cout << "Commands (sent to AVR as plaintext):" << endl;
                        for(cmd = plaincmd.begin(); cmd != plaincmd.end(); cmd++)
                            cout << "  " << cmd->first << endl;
                        cout << "Terminal commands (not sent to AVR):" << endl <<
                                "  help   (? or h)" << endl <<
                                "  quit   (q)" << endl;
                    } else if(rbuf[0] == 'q') { // quit
                        cout << "Bye!" << endl;
                        break;
                    } else
                        cerr << "Unknown command: " << rbuf << endl;
                }
            }
        }
    } catch(AesBadKeyException& e) {
        cerr << "Error: Could not read key; reason: " << e.what() << "." << endl;
        return 1;
    }

    return 0;
}

