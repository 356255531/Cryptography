/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : StateGenerator.h
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Declaration of class StateGenerator which creates AES state filled
 *          up with pseudo random data.
 *
 * $Id: StateGenerator.h 9 2011-06-28 14:53:01Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

#ifndef STATEGENERATOR_H
#define	STATEGENERATOR_H

using namespace std;

class StateGenerator
{
public:
    StateGenerator();
    string getState(const char *s);
};

#endif	/* STATEGENERATOR_H */

