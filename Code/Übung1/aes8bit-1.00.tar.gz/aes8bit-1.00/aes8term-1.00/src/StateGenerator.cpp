/*
 * Project: aes8bit - AES implementation for 8 bit microcontrollers (AVR ATmega)
 * File   : StateGenerator.cpp
 * Author : Oliver Mueller <oliver@cogito-ergo-sum.org>
 * Purpose: Definition of class StateGenerator which creates AES state filled
 *          up with pseudo random data.
 *
 * $Id: StateGenerator.cpp 9 2011-06-28 14:53:01Z oliver $
 *
 * Copyright (c) 2011 Oliver Mueller.
 * All rights reserved.
 * http://www.cogito-ergo-sum.org
 *
 * This software is provided 'as-is', without any express or implied warranty.
 * In no event will the author be held liable for any damages arising from
 * the use of this software.
 *
 */

/*
 * Note: This implementation is not safe in a cryptanalytical sense!!!
 */

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <string>
#include "StateGenerator.h"

using namespace std;

StateGenerator::StateGenerator()
{
    srand(time(NULL));
}

string StateGenerator::getState(const char *s)
{
    string state;
    char checksum = 0, c;
    for(int i = 0, j = strlen(s); i < 15; i++) {
        if(i <= j)
            c = s[i];
        else
            c = (char) rand();
        checksum ^= c;
        state.append(1, c);
    }
    state.append(1, checksum);
    return state;
}
