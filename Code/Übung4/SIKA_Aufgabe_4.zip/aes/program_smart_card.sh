avrdude -p m644 -c avrisp2 -P usb -B 5 -U flash:w:student.hex
